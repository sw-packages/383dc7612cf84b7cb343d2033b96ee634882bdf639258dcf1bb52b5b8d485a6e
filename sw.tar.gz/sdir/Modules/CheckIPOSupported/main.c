int foo(void);

int main(void)
{
  return foo();
}
